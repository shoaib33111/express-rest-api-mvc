
const Course = require("../models/Course");

const createCourse = async (req, res) => {
    try {
        const { title, description, instructor, category, duration, price } = req.body;

        if (!title || !description || !instructor || !category || duration == null || price == null) {
            return res.status(400).json({
                message: "All fields are required"
            });
        }

        const course = await Course.create({
            title,
            description,
            instructor,
            category,
            duration,
            price
        });

        res.status(201).json({
            message: "Course created successfully",
            course
        });
    } catch (error) {
        res.status(500).json({
            message: "Failed to create course",
            error: error.message
        });
    }
};

const getCourses = async (req, res) => {
    try {
        const courses = await Course.find().populate("category", "name description");

        res.status(200).json({
            count: courses.length,
            courses
        });
    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch courses",
            error: error.message
        });
    }
};

const getCourseById = async (req, res) => {
    try {
        const course = await Course.findById(req.params.id)
            .populate("category", "name description");

        if (!course) {
            return res.status(404).json({
                message: "Course not found"
            });
        }

        res.status(200).json({ course });
    } catch (error) {
        res.status(400).json({
            message: "Invalid course ID",
            error: error.message
        });
    }
};

const updateCourse = async (req, res) => {
    try {
        const course = await Course.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        ).populate("category", "name description");

        if (!course) {
            return res.status(404).json({
                message: "Course not found"
            });
        }

        res.status(200).json({
            message: "Course updated successfully",
            course
        });
    } catch (error) {
        res.status(400).json({
            message: "Failed to update course",
            error: error.message
        });
    }
};

const deleteCourse = async (req, res) => {
    try {
        const course = await Course.findByIdAndDelete(req.params.id);

        if (!course) {
            return res.status(404).json({
                message: "Course not found"
            });
        }

        res.status(200).json({
            message: "Course deleted successfully"
        });
    } catch (error) {
        res.status(400).json({
            message: "Invalid course ID",
            error: error.message
        });
    }
};

module.exports = {
    createCourse,
    getCourses,
    getCourseById,
    updateCourse,
    deleteCourse
};
