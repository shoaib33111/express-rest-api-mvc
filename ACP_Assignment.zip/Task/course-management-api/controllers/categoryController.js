
const Category = require("../models/Category");

const createCategory = async (req, res) => {
    try {
        const { name, description } = req.body;

        if (!name || !name.trim()) {
            return res.status(400).json({
                message: "Category name is required"
            });
        }

        const category = await Category.create({
            name: name.trim(),
            description
        });

        res.status(201).json({
            message: "Category created successfully",
            category
        });
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).json({
                message: "Category name already exists"
            });
        }

        res.status(500).json({
            message: "Failed to create category",
            error: error.message
        });
    }
};

const getCategories = async (req, res) => {
    try {
        const categories = await Category.find();

        res.status(200).json({
            count: categories.length,
            categories
        });
    } catch (error) {
        res.status(500).json({
            message: "Failed to fetch categories",
            error: error.message
        });
    }
};

const getCategoryById = async (req, res) => {
    try {
        const category = await Category.findById(req.params.id);

        if (!category) {
            return res.status(404).json({
                message: "Category not found"
            });
        }

        res.status(200).json({ category });
    } catch (error) {
        res.status(400).json({
            message: "Invalid category ID"
        });
    }
};

const updateCategory = async (req, res) => {
    try {
        if (
            req.body.name !== undefined &&
            (typeof req.body.name !== "string" || !req.body.name.trim())
        ) {
            return res.status(400).json({
                message: "Category name cannot be empty"
            });
        }

        const updateData = { ...req.body };

        if (typeof updateData.name === "string") {
            updateData.name = updateData.name.trim();
        }

        const category = await Category.findByIdAndUpdate(
            req.params.id,
            updateData,
            { new: true, runValidators: true }
        );

        if (!category) {
            return res.status(404).json({
                message: "Category not found"
            });
        }

        res.status(200).json({
            message: "Category updated successfully",
            category
        });
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).json({
                message: "Category name already exists"
            });
        }

        res.status(400).json({
            message: "Failed to update category",
            error: error.message
        });
    }
};

const deleteCategory = async (req, res) => {
    try {
        const category = await Category.findByIdAndDelete(req.params.id);

        if (!category) {
            return res.status(404).json({
                message: "Category not found"
            });
        }

        res.status(200).json({
            message: "Category deleted successfully"
        });
    } catch (error) {
        res.status(400).json({
            message: "Invalid category ID"
        });
    }
};

module.exports = {
    createCategory,
    getCategories,
    getCategoryById,
    updateCategory,
    deleteCategory
};
