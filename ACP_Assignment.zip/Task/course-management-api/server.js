
require("dotenv").config();

const express = require("express");
const connectDB = require("./config/db");
const authRoutes = require("./routes/authRoutes");
const categoryRoutes = require("./routes/categoryRoutes");
const courseRoutes = require("./routes/courseRoutes");

const app = express();

app.use(express.json());

// Test GET route
app.get("/test", (req, res) => {
    res.send("Server is working!");
});

// Test POST route
app.post("/test-post", (req, res) => {
    res.json({
        message: "POST route is working!"
    });
});

// Authentication routes
app.use("/api/auth", authRoutes);

// Category routes
app.use("/api/categories", categoryRoutes);

// Course routes
app.use("/api/courses", courseRoutes);

// Home route
app.get("/", (req, res) => {
    res.json({
        message: "Course Management API is running!"
    });
});

const PORT = process.env.PORT || 5000;

const startServer = async () => {
    await connectDB();

    app.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`);
        console.log("Test POST: http://localhost:5000/test-post");
        console.log("Signup: http://localhost:5000/api/auth/signup");
        console.log("Categories: http://localhost:5000/api/categories");
        console.log("Courses: http://localhost:5000/api/courses");
    });
};

startServer();
